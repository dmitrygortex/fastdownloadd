package org.miit.adm.beatsshopadm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeatsShopAdmApplication {

    public static void main(String[] args) {
        SpringApplication.run(BeatsShopAdmApplication.class, args);
    }

}
